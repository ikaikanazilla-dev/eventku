<?php $__env->startSection('content'); ?>
    <section class="page-head">
        <div class="container">
            <span class="eyebrow">KATALOG EVENTKU</span>
            <h1>Jelajahi event pilihan.</h1>
            <p class="muted">Cari agenda yang sesuai dengan minat, waktu, dan lokasimu.</p>

            <form class="filters" method="GET" action="<?php echo e(route('events.index')); ?>" aria-label="Filter event">
                <div class="filter-search">
                    <label class="sr-only" for="event-search">Cari event atau lokasi</label>
                    <input id="event-search" class="input" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama event atau lokasi...">
                </div>
                <div>
                    <label class="sr-only" for="event-category">Kategori</label>
                    <select id="event-category" class="select" name="category">
                        <option value="">Semua kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" <?php if(request('category') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="sr-only" for="event-date">Tanggal event</label>
                    <input id="event-date" class="input" type="date" name="date" value="<?php echo e(request('date')); ?>" aria-label="Tanggal event">
                </div>
                <button class="btn btn-primary" type="submit">Terapkan</button>
                <?php if(request()->hasAny(['q', 'category', 'date'])): ?>
                    <a class="btn btn-ghost" href="<?php echo e(route('events.index')); ?>">Reset</a>
                <?php endif; ?>
            </form>
        </div>
    </section>

    <section class="section">
        <div class="container">
            <?php if($events->count()): ?>
                <div class="filter-summary">
                    <span>Menampilkan <strong><?php echo e($events->total()); ?></strong> event yang tersedia.</span>
                    <?php if(request()->hasAny(['q', 'category', 'date'])): ?><span>Filter sedang aktif</span><?php endif; ?>
                </div>
                <div class="event-grid">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal07bdbe031a4c57e4cd3488994f94e999 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-card','data' => ['event' => $event]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['event' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $attributes = $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $component = $__componentOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="pagination"><?php echo e($events->links()); ?></div>
            <?php else: ?>
                <div class="card empty">
                    <span class="eyebrow">BELUM ADA HASIL</span>
                    <h2>Event tidak ditemukan</h2>
                    <p class="muted">Coba ubah kata kunci, kategori, atau tanggal pencarianmu.</p>
                    <a class="btn btn-primary" href="<?php echo e(route('events.index')); ?>">Lihat semua event</a>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\public\events.blade.php ENDPATH**/ ?>