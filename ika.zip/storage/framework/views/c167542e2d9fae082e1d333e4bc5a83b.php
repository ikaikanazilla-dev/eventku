<?php $__env->startSection('content'); ?>
    <div class="dashboard-shell">
        <aside class="sidebar">
            <a class="active" href="<?php echo e(route('participant.dashboard')); ?>">Ringkasan</a>
            <a href="<?php echo e(route('events.index')); ?>">Jelajahi Event</a>
            <a href="<?php echo e(route('participant.tickets')); ?>">Tiket Saya</a>
            <a href="<?php echo e(route('profile.edit')); ?>">Profil</a>
        </aside>
        <div class="dash-main">
            <div class="dash-top">
                <div><span class="eyebrow">RUANG PESERTA</span><h1>Halo, <?php echo e(auth()->user()->name); ?></h1><p class="muted">Kelola event yang kamu ikuti dan akses tiket digitalmu.</p></div>
                <a class="btn btn-primary" href="<?php echo e(route('events.index')); ?>">Jelajahi event</a>
            </div>
            <div class="stat-grid" style="grid-template-columns:repeat(2,minmax(0,220px))">
                <div class="stat-card"><label>Tiket valid</label><strong><?php echo e($stats['valid']); ?></strong><span class="badge badge-success">Siap digunakan</span></div>
                <div class="stat-card"><label>Sudah digunakan</label><strong><?php echo e($stats['used']); ?></strong><span class="badge badge-neutral">Riwayat check-in</span></div>
            </div>
            <div class="section-heading"><div><h2>Event mendatang</h2><p class="muted">Tiket digital terbaru yang kamu miliki.</p></div><a href="<?php echo e(route('participant.tickets')); ?>" class="btn btn-soft">Lihat semua</a></div>
            <?php if($registrations->count()): ?>
                <div class="event-grid">
                    <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="event-card">
                            <a class="event-card-media" href="<?php echo e(route('participant.ticket.show', $registration->digitalTicket)); ?>"><img src="<?php echo e($registration->event->poster_url); ?>" alt="Poster <?php echo e($registration->event->name); ?>" loading="lazy" width="640" height="360"></a>
                            <div class="event-card-body">
                                <span class="badge badge-success">Tiket valid</span>
                                <h3><?php echo e($registration->event->name); ?></h3>
                                <div class="meta"><span><?php echo e($registration->event->start_at->format('d M Y, H:i')); ?> WIB</span><span title="<?php echo e($registration->event->location); ?>"><?php echo e(Str::limit($registration->event->location, 22)); ?></span></div>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('participant.ticket.show', $registration->digitalTicket)); ?>" style="margin-top:auto">Buka tiket digital</a>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="card empty"><h3>Belum ada tiket</h3><p class="muted">Jelajahi event untuk menemukan agenda yang ingin kamu ikuti.</p><a class="btn btn-primary" href="<?php echo e(route('events.index')); ?>">Jelajahi event</a></div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/participant/dashboard.blade.php ENDPATH**/ ?>