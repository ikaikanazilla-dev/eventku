<?php $__env->startSection('organizer-content'); ?>
    <section class="section">
        <div class="container">
            <div class="section-heading"><div><span class="eyebrow">REGISTRATION MONITOR</span><h1>Daftar Pendaftar</h1><p class="muted">Pantau peserta dan status tiket dari seluruh event milikmu.</p></div></div>
            <div class="table-wrap"><table class="table"><thead><tr><th>Peserta</th><th>Event</th><th>Tiket</th><th>Terdaftar</th><th>Status</th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td><strong><?php echo e($registration->user->name); ?></strong><br><small><?php echo e($registration->user->email); ?></small></td><td><?php echo e($registration->event->name); ?></td><td><?php echo e($registration->ticketType->name); ?></td><td><?php echo e($registration->registered_at->format('d M Y H:i')); ?></td><td><span class="badge <?php echo e($registration->digitalTicket?->status === 'used' ? 'badge-neutral' : 'badge-success'); ?>"><?php echo e(ucfirst($registration->digitalTicket?->status ?? $registration->status)); ?></span></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty">Belum ada pendaftar.</td></tr>
                <?php endif; ?>
            </tbody></table></div>
            <div class="pagination"><?php echo e($registrations->links()); ?></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\organizer\registrations.blade.php ENDPATH**/ ?>