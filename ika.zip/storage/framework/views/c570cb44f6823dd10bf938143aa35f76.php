<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'Eventku &mdash; Event dan Tiket Digital'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <header class="ek-nav">
        <div class="nav-inner">
            <a class="brand" href="<?php echo e(route('home')); ?>" aria-label="Eventku, kembali ke beranda">
                <span class="brand-mark" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none"><path d="M4 7.5 6 5h12l2 2.5v10A1.5 1.5 0 0 1 18.5 19h-13A1.5 1.5 0 0 1 4 17.5v-10Z" stroke="currentColor" stroke-width="1.8"/><path d="M8 5v4m8-4v4M7 13h10M7 16h5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                </span>
                <span>EVENTKU</span>
            </a>

            <nav class="nav-main" aria-label="Navigasi utama">
                <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                <a class="nav-link <?php echo e(request()->routeIs('events.*') ? 'active' : ''); ?>" href="<?php echo e(route('events.index')); ?>">Jelajahi Event</a>
                <a class="nav-link" href="<?php echo e(route('home')); ?>#cara-kerja">Cara Mengikuti</a>
            </nav>

            <div class="nav-actions">
                <?php if(auth()->guard()->check()): ?>
                    <a class="nav-action-link" href="<?php echo e(route(auth()->user()->role.'.dashboard')); ?>">Dashboard</a>
                    <?php if(auth()->user()->role === 'participant'): ?>
                        <a class="nav-action-link" href="<?php echo e(route('participant.tickets')); ?>">Tiket Saya</a>
                    <?php elseif(auth()->user()->role === 'organizer'): ?>
                        <a class="nav-action-link" href="<?php echo e(route('organizer.events')); ?>">Event Saya</a>
                    <?php elseif(auth()->user()->role === 'admin'): ?>
                        <a class="nav-action-link" href="<?php echo e(route('admin.events')); ?>">Moderasi</a>
                    <?php endif; ?>
                    <div class="profile-menu" data-profile-menu>
                        <button class="profile-trigger" type="button" data-profile-toggle aria-expanded="false" aria-haspopup="true">
                            <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                            <span class="profile-name"><?php echo e(Str::limit(auth()->user()->name, 16)); ?></span>
                            <span class="chevron" aria-hidden="true">⌄</span>
                        </button>
                        <div class="profile-dropdown" data-profile-dropdown hidden>
                            <div class="profile-dropdown-head"><strong><?php echo e(auth()->user()->name); ?></strong><small><?php echo e(ucfirst(auth()->user()->role)); ?></small></div>
                            <a href="<?php echo e(route('profile.edit')); ?>">Profil Saya</a>
                            <a href="<?php echo e(route(auth()->user()->role.'.dashboard')); ?>">Dashboard</a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
                        </div>
                    </div>
                <?php else: ?>
                    <a class="nav-action-link" href="<?php echo e(route('login')); ?>">Masuk</a>
                    <a class="btn btn-primary btn-sm nav-register" href="<?php echo e(route('register')); ?>">Daftar Gratis</a>
                <?php endif; ?>
            </div>

            <button class="mobile-toggle" type="button" data-mobile-toggle aria-expanded="false" aria-controls="mobile-nav" aria-label="Buka menu navigasi">
                <span></span><span></span><span></span>
            </button>
        </div>

        <div class="mobile-panel" id="mobile-nav" data-mobile-panel hidden>
            <nav aria-label="Navigasi mobile">
                <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">Beranda</a>
                <a class="nav-link <?php echo e(request()->routeIs('events.*') ? 'active' : ''); ?>" href="<?php echo e(route('events.index')); ?>">Jelajahi Event</a>
                <a class="nav-link" href="<?php echo e(route('home')); ?>#cara-kerja">Cara Mengikuti</a>
                <?php if(auth()->guard()->check()): ?>
                    <a class="mobile-cta" href="<?php echo e(route(auth()->user()->role.'.dashboard')); ?>">Dashboard</a>
                    <?php if(auth()->user()->role === 'participant'): ?>
                        <a class="mobile-cta" href="<?php echo e(route('participant.tickets')); ?>">Tiket Saya</a>
                    <?php elseif(auth()->user()->role === 'organizer'): ?>
                        <a class="mobile-cta" href="<?php echo e(route('organizer.events')); ?>">Event Saya</a>
                    <?php else: ?>
                        <a class="mobile-cta" href="<?php echo e(route('admin.events')); ?>">Moderasi</a>
                    <?php endif; ?>
                    <a class="nav-link" href="<?php echo e(route('profile.edit')); ?>">Profil Saya</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="nav-link" type="submit">Keluar</button></form>
                <?php else: ?>
                    <a class="mobile-cta" href="<?php echo e(route('login')); ?>">Masuk atau Daftar</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <?php if(!session()->has('checkin_result') && session('success')): ?>
        <div class="toast toast-success" role="status" aria-live="polite"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(!session()->has('checkin_result') && session('error')): ?>
        <div class="toast toast-error" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="toast toast-error" role="alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <main><?php echo $__env->yieldContent('content'); ?></main>

    <footer class="footer">
        <div>
            <a class="brand" href="<?php echo e(route('home')); ?>"><span class="brand-mark" aria-hidden="true">✦</span> EVENTKU</a>
            <p>Temukan event, daftar dengan mudah, dan simpan tiket digitalmu dalam satu tempat.</p>
        </div>
        <div>
            <strong>Jelajahi</strong>
            <a href="<?php echo e(route('events.index')); ?>">Semua Event</a>
            <a href="<?php echo e(route('events.index')); ?>">Cari berdasarkan tanggal</a>
            <a href="<?php echo e(route('home')); ?>#cara-kerja">Cara Mengikuti</a>
        </div>
        <div>
            <strong>Ruang Kerja</strong>
            <a href="<?php echo e(route('register')); ?>">Daftar sebagai peserta</a>
            <a href="<?php echo e(route('login')); ?>">Kelola event</a>
            <a href="<?php echo e(route('login')); ?>">Akses check-in</a>
        </div>
        <small>&copy; <?php echo e(date('Y')); ?> Eventku. Platform event dan tiket digital.</small>
    </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Eventku\resources\views/layouts/app.blade.php ENDPATH**/ ?>