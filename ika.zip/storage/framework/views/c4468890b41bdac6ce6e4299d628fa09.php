<?php $__env->startSection('organizer-content'); ?>
            <div class="dash-top">
                <div><span class="eyebrow">RUANG PENYELENGGARA</span><h1>Dashboard event</h1><p class="muted">Kelola event, pantau pendaftar, dan lakukan check-in dari satu tempat.</p></div>
                <a class="btn btn-primary" href="<?php echo e(route('organizer.event.create')); ?>">Buat event baru</a>
            </div>
            <div class="stat-grid">
                <div class="stat-card"><label>Total event</label><strong><?php echo e($stats['events']); ?></strong><span class="muted">Semua event milikmu</span></div>
                <div class="stat-card"><label>Total pendaftar</label><strong><?php echo e($stats['registrations']); ?></strong><span class="muted">Pendaftaran aktif</span></div>
                <div class="stat-card"><label>Dipublikasikan</label><strong><?php echo e($stats['published']); ?></strong><span class="badge badge-success">Tampil di katalog</span></div>
                <div class="stat-card"><label>Check-in berhasil</label><strong><?php echo e($stats['checkins']); ?></strong><span class="muted">Data kehadiran</span></div>
            </div>
            <div class="section-heading"><div><h2>Event terbaru</h2><p class="muted">Pantau jadwal dan status event milikmu.</p></div><a href="<?php echo e(route('organizer.events')); ?>" class="btn btn-soft">Lihat semua</a></div>
            <div class="table-wrap">
                <table class="table"><thead><tr><th>Nama event</th><th>Jadwal</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr><td><strong><?php echo e($event->name); ?></strong><br><small><?php echo e($event->category->name); ?></small></td><td><?php echo e($event->start_at->format('d M Y')); ?><br><small><?php echo e($event->location); ?></small></td><td><span class="badge <?php echo e($event->status === 'published' ? 'badge-success' : ($event->status === 'rejected' ? 'badge-danger' : 'badge-warning')); ?>"><?php echo e(ucfirst($event->status)); ?></span></td><td><a class="btn btn-soft btn-sm" href="<?php echo e(route('organizer.event.show', $event)); ?>">Buka detail</a></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="empty">Belum ada event. Buat event pertamamu sekarang.</td></tr>
                    <?php endif; ?>
                </tbody></table>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\organizer\dashboard.blade.php ENDPATH**/ ?>