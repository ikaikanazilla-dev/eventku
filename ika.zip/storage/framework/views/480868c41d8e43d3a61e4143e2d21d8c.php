<?php $__env->startSection('content'); ?>
    <div class="auth-shell">
        <div class="auth-card">
            <span class="eyebrow">AKSES EVENTKU</span>
            <h1>Selamat datang kembali.</h1>
            <p>Masuk untuk mengakses tiket digital atau mengelola eventmu.</p>
            <form method="POST" action="<?php echo e(route('login.store')); ?>" data-submit-once>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" class="input" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" class="input" type="password" name="password" autocomplete="current-password" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <label class="muted" for="remember"><input id="remember" type="checkbox" name="remember"> Ingat saya di perangkat ini</label>
                <button class="btn btn-primary" type="submit">Masuk ke Eventku <span aria-hidden="true">&rarr;</span></button>
            </form>
            <p>Belum punya akun peserta? <a href="<?php echo e(route('register')); ?>">Daftar gratis</a></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\auth\login.blade.php ENDPATH**/ ?>