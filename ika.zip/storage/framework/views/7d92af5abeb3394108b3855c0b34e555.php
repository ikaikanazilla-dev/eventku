<?php $__env->startSection('organizer-content'); ?>
    <section class="section">
        <div class="container">
            <div class="section-heading">
                <div>
                    <span class="badge <?php echo e($event->status === 'published' ? 'badge-success' : ''); ?>"><?php echo e(ucfirst($event->status)); ?></span>
                    <h1><?php echo e($event->name); ?></h1>
                    <p class="muted"><?php echo e($event->start_at->format('d M Y H:i')); ?> · <?php echo e($event->location); ?></p>
                </div>
                <div class="table-actions">
                    <?php if(in_array($event->status, ['draft', 'rejected'], true)): ?>
                        <form method="POST" action="<?php echo e(route('organizer.event.submit', $event)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary">Ajukan Review</button>
                        </form>
                        <a class="btn btn-soft" href="<?php echo e(route('organizer.event.edit', $event)); ?>">Edit</a>
                        <form method="POST" action="<?php echo e(route('organizer.event.destroy', $event)); ?>" onsubmit="return confirm('Hapus event ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit">Hapus</button>
                        </form>
                    <?php endif; ?>
                    <?php if($event->status === 'published'): ?>
                        <a class="btn btn-primary" href="<?php echo e(route('organizer.checkin', $event)); ?>">QR Check-in</a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($event->rejection_reason): ?>
                <div class="card" style="border-color:#fecdca;color:#b42318;margin-bottom:18px"><strong>Alasan penolakan</strong><p><?php echo e($event->rejection_reason); ?></p></div>
            <?php endif; ?>

            <div class="split">
                <div>
                    <div class="card">
                        <img class="detail-cover" src="<?php echo e($event->poster_url); ?>" alt="Poster <?php echo e($event->name); ?>">
                        <h2>Tentang Event</h2>
                        <p style="white-space:pre-line;line-height:1.7;color:var(--muted)"><?php echo e($event->description); ?></p>
                    </div>
                </div>
                <div>
                    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
                        <div class="stat-card"><label>Kuota</label><strong><?php echo e($event->ticketTypes->sum('quota')); ?></strong></div>
                        <div class="stat-card"><label>Pendaftar</label><strong><?php echo e($event->registrations->where('status', 'registered')->count()); ?></strong></div>
                    </div>
                    <div class="card">
                        <h3>Jenis Tiket</h3>
                        <?php $__currentLoopData = $event->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><strong><?php echo e($ticket->name); ?></strong><br><span class="muted"><?php echo e($ticket->remainingQuota()); ?> tersisa dari <?php echo e($ticket->quota); ?></span></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:18px">
                <h2>Peserta terbaru</h2>
                <div class="table-wrap">
                    <table class="table">
                        <thead><tr><th>Peserta</th><th>Kode</th><th>Status Tiket</th></tr></thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $event->registrations->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr><td><?php echo e($registration->user->name); ?><br><small><?php echo e($registration->user->email); ?></small></td><td><?php echo e($registration->registration_code); ?></td><td><span class="badge"><?php echo e(ucfirst($registration->digitalTicket?->status ?? 'pending')); ?></span></td></tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="3" class="empty">Belum ada pendaftar.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/organizer/event-show.blade.php ENDPATH**/ ?>