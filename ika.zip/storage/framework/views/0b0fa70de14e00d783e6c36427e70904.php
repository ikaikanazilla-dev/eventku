<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container" style="max-width:720px">
            <div class="section-heading">
                <div><span class="eyebrow">PENGATURAN AKUN</span><h1>Profil Saya</h1><p class="muted">Perbarui informasi yang digunakan di Eventku.</p></div>
            </div>
            <div class="card">
                <form method="POST" action="<?php echo e(route('profile.update')); ?>" class="form-grid" data-submit-once>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label for="name">Nama</label>
                        <input id="name" class="input" name="name" value="<?php echo e(auth()->user()->name); ?>" autocomplete="name" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input id="email" class="input" value="<?php echo e(auth()->user()->email); ?>" disabled>
                    </div>
                    <div class="form-group">
                        <label for="phone">Nomor telepon</label>
                        <input id="phone" class="input" name="phone" value="<?php echo e(auth()->user()->phone); ?>" autocomplete="tel">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="role">Peran</label>
                        <input id="role" class="input" value="<?php echo e(ucfirst(auth()->user()->role)); ?>" disabled>
                    </div>
                    <div class="form-group full"><button class="btn btn-primary" type="submit">Simpan perubahan</button></div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\profile\edit.blade.php ENDPATH**/ ?>