<?php $__env->startSection('content'); ?>
    <?php
        $adminNavigation = [
            ['route' => 'admin.dashboard', 'pattern' => 'admin.dashboard', 'label' => 'Dashboard', 'icon' => '⌂'],
            ['route' => 'admin.events', 'pattern' => 'admin.events', 'label' => 'Moderasi Event', 'icon' => '◈'],
            ['route' => 'admin.categories', 'pattern' => 'admin.categories', 'label' => 'Kategori', 'icon' => '▦'],
            ['route' => 'admin.users', 'pattern' => 'admin.users', 'label' => 'Pengguna', 'icon' => '◎'],
            ['route' => 'admin.logs', 'pattern' => 'admin.logs', 'label' => 'Log Aktivitas', 'icon' => '≡'],
        ];
        $currentAdminPage = collect($adminNavigation)->first(fn ($item) => request()->routeIs($item['pattern']));
        $currentAdminPage = $currentAdminPage['label'] ?? 'Admin';
        if (request()->routeIs('admin.event.*')) {
            $currentAdminPage = 'Moderasi Event';
        }
    ?>
    <div class="dashboard-shell admin-dashboard-shell">
        <button class="sidebar-toggle" type="button" data-sidebar-toggle aria-expanded="false" aria-controls="admin-sidebar">☰ <span>Menu admin</span></button>
        <div class="sidebar-backdrop" data-sidebar-backdrop hidden></div>
        <aside class="sidebar admin-sidebar" id="admin-sidebar" aria-label="Navigasi admin">
            <?php $__currentLoopData = $adminNavigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($isActive = request()->routeIs($item['pattern']) || ($item['route'] === 'admin.events' && request()->routeIs('admin.event.*'))); ?>
                <a class="<?php echo e($isActive ? 'active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>"><span class="sidebar-icon" aria-hidden="true"><?php echo e($item['icon']); ?></span><?php echo e($item['label']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </aside>
        <div class="dash-main">
            <nav class="breadcrumb admin-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a>
                <?php if(! request()->routeIs('admin.dashboard')): ?>
                    <span aria-hidden="true">/</span><span><?php echo e($currentAdminPage); ?></span>
                <?php endif; ?>
            </nav>
            <?php echo $__env->yieldContent('admin-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\layouts\admin.blade.php ENDPATH**/ ?>