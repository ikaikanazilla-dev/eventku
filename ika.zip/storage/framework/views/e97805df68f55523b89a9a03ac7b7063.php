<?php $__env->startSection('admin-content'); ?>
    <section class="section">
        <div class="container">
            <div class="section-heading">
                <div>
                    <span class="badge"><?php echo e(ucfirst($event->status)); ?></span>
                    <h1><?php echo e($event->name); ?></h1>
                    <p class="muted"><?php echo e($event->start_at->format('d M Y H:i')); ?> · <?php echo e($event->location); ?> · <?php echo e($event->organizer->name); ?></p>
                </div>
                <div class="table-actions">
                    <a class="btn btn-soft" href="<?php echo e(route('admin.event.edit', $event)); ?>">Edit event</a>
                    <?php if($event->status === 'pending'): ?>
                        <form method="POST" action="<?php echo e(route('admin.event.approve', $event)); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-primary" type="submit">Setujui &amp; Publikasikan</button>
                        </form>
                        <form method="POST" action="<?php echo e(route('admin.event.reject', $event)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="rejection_reason" value="Perlu revisi sebelum dipublikasikan.">
                            <button class="btn btn-danger" type="submit">Tolak</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <?php if($event->rejection_reason): ?>
                <div class="card" style="border-color:#fecdca;color:#b42318;margin-bottom:18px">
                    <strong>Alasan penolakan</strong>
                    <p><?php echo e($event->rejection_reason); ?></p>
                </div>
            <?php endif; ?>

            <div class="detail-grid">
                <div class="card">
                    <img class="detail-cover" src="<?php echo e($event->poster_url); ?>" alt="Poster <?php echo e($event->name); ?>">
                    <h2>Tentang Event</h2>
                    <p style="white-space:pre-line;line-height:1.8;color:var(--muted)"><?php echo e($event->description); ?></p>
                </div>
                <div>
                    <div class="stat-grid" style="grid-template-columns:1fr 1fr">
                        <div class="stat-card"><label>Kategori</label><strong><?php echo e($event->category->name); ?></strong></div>
                        <div class="stat-card"><label>Kuota</label><strong><?php echo e($event->ticketTypes->sum('quota')); ?></strong></div>
                        <div class="stat-card"><label>Pendaftar</label><strong><?php echo e($event->registrations->where('status','registered')->count()); ?></strong></div>
                        <div class="stat-card"><label>Registrasi</label><strong><?php echo e($event->registration_start_at->format('d M')); ?>–<?php echo e($event->registration_end_at->format('d M Y')); ?></strong></div>
                    </div>
                    <div class="card">
                        <h3>Jenis Tiket</h3>
                        <?php $__currentLoopData = $event->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><strong><?php echo e($ticket->name); ?></strong><br><span class="muted"><?php echo e($ticket->remainingQuota()); ?> tersisa dari <?php echo e($ticket->quota); ?></span></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/admin/event-show.blade.php ENDPATH**/ ?>