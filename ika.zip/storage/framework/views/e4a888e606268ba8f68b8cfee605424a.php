<?php $__env->startSection('content'); ?>
    <section class="hero">
        <div class="container hero-grid">
            <div>
                <span class="eyebrow">EVENTKU / TEMUKAN PENGALAMAN BARU</span>
                <h1>Temukan event seru <span>di sekitarmu.</span></h1>
                <p>Jelajahi seminar, workshop, dan acara komunitas. Daftar dengan mudah dan simpan tiketmu secara digital.</p>
                <form class="searchbar" method="GET" action="<?php echo e(route('events.index')); ?>">
                    <label class="sr-only" for="hero-search">Cari event</label>
                    <input id="hero-search" name="q" placeholder="Cari nama event atau lokasi...">
                    <button class="btn btn-primary" type="submit">Jelajahi Event</button>
                </form>
                <div class="hero-note" aria-label="Fitur Eventku">
                    <span>Daftar online</span>
                    <span>Tiket digital</span>
                    <span>QR untuk check-in</span>
                </div>
            </div>
            <img class="hero-img" src="<?php echo e(asset('storage/events/hero-conference.jpg')); ?>" alt="Peserta konferensi mengikuti sesi presentasi" width="800" height="450">
        </div>
    </section>

    <section class="section">
        <div class="container">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">PILIHAN UNTUKMU</span>
                    <h2>Event yang akan datang</h2>
                    <p class="muted">Temukan agenda berikutnya dan pilih pengalaman yang paling sesuai.</p>
                </div>
                <a class="btn btn-soft" href="<?php echo e(route('events.index')); ?>">Lihat semua event <span aria-hidden="true">&rarr;</span></a>
            </div>

            <?php if($events->count()): ?>
                <div class="event-grid">
                    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginal07bdbe031a4c57e4cd3488994f94e999 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.event-card','data' => ['event' => $event,'lazy' => $loop->index > 0]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('event-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['event' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($event),'lazy' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($loop->index > 0)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $attributes = $__attributesOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__attributesOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999)): ?>
<?php $component = $__componentOriginal07bdbe031a4c57e4cd3488994f94e999; ?>
<?php unset($__componentOriginal07bdbe031a4c57e4cd3488994f94e999); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <div class="card empty">
                    <h3>Belum ada event publik</h3>
                    <p class="muted">Nantikan event terbaru dari penyelenggara Eventku.</p>
                    <a class="btn btn-primary" href="<?php echo e(route('events.index')); ?>">Buka katalog event</a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php if($events->pluck('category')->filter()->count()): ?>
        <section class="section" style="padding-top:0">
            <div class="container">
                <div class="section-heading">
                    <div>
                        <span class="eyebrow">JELAJAH BERDASARKAN MINAT</span>
                        <h2>Kategori event</h2>
                    </div>
                </div>
                <div class="category-grid">
                    <?php $__currentLoopData = $events->pluck('category')->filter()->unique('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="category-card" href="<?php echo e(route('events.index', ['category' => $category->id])); ?>">
                            <span class="category-icon" aria-hidden="true">✦</span>
                            <span><strong><?php echo e($category->name); ?></strong><small>Lihat event</small></span>
                            <span aria-hidden="true">&rarr;</span>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <section id="cara-kerja" class="section how">
        <div class="container">
            <div class="section-heading">
                <div>
                    <span class="eyebrow">TIGA LANGKAH SEDERHANA</span>
                    <h2>Cara mengikuti event</h2>
                    <p class="muted">Semua kebutuhan peserta ada di alur yang singkat.</p>
                </div>
            </div>
            <div class="how-grid">
                <div class="how-card"><span class="how-num">01</span><h3>Pilih event</h3><p class="muted">Cari event berdasarkan topik, tanggal, atau lokasi yang kamu inginkan.</p></div>
                <div class="how-card"><span class="how-num">02</span><h3>Daftar dan simpan tiket</h3><p class="muted">Masuk sebagai peserta, pilih tiket gratis, lalu buka tiket digitalmu.</p></div>
                <div class="how-card"><span class="how-num">03</span><h3>Tunjukkan QR saat datang</h3><p class="muted">Gunakan QR pada tiket digital untuk proses check-in di lokasi event.</p></div>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="container cta">
            <div>
                <span class="eyebrow">UNTUK PENYELENGGARA</span>
                <h2>Siapkan eventmu di Eventku.</h2>
                <p>Buat event, kelola kuota, lihat pendaftar, dan lakukan check-in dari ruang kerja penyelenggara.</p>
                <a class="btn btn-primary" href="<?php echo e(auth()->check() && auth()->user()->role === 'organizer' ? route('organizer.dashboard') : route('login')); ?>"><?php echo e(auth()->check() && auth()->user()->role === 'organizer' ? 'Buka dashboard' : 'Masuk untuk mulai'); ?></a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/public/home.blade.php ENDPATH**/ ?>