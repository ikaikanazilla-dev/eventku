<?php ($adminMode = $adminMode ?? false); ?>


<?php $__env->startSection($adminMode ? 'admin-content' : 'organizer-content'); ?>
    <section class="section">
        <div class="container" style="max-width:920px">
            <div class="section-heading">
                <div>
                    <span class="eyebrow"><?php echo e($adminMode ? 'RUANG ADMIN' : 'RUANG PENYELENGGARA'); ?></span>
                    <h1><?php echo e($adminMode ? 'Edit Event' : ($event ? 'Edit Event' : 'Buat Event Baru')); ?></h1>
                    <p class="muted"><?php echo e($adminMode ? 'Perbarui jadwal atau informasi event tanpa membuat ulang tiket dan registrasi.' : ($event ? 'Perbarui informasi event lalu simpan perubahan.' : 'Lengkapi informasi event. Event baru akan tersimpan sebagai draft dan perlu diajukan untuk review admin.')); ?></p>
                </div>
            </div>
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route($adminMode ? 'admin.dashboard' : 'organizer.dashboard')); ?>">Dashboard</a><span aria-hidden="true">/</span><a href="<?php echo e(route($adminMode ? 'admin.events' : 'organizer.events')); ?>"><?php echo e($adminMode ? 'Moderasi Event' : 'Event Saya'); ?></a><span aria-hidden="true">/</span><span><?php echo e($event ? 'Edit Event' : 'Buat Event'); ?></span>
            </nav>

            <div class="card">
                <p class="form-help" style="margin-bottom:22px"><span class="required-mark" aria-hidden="true">*</span> Wajib diisi. Pastikan jadwal pendaftaran berakhir sebelum event dimulai.</p>
                <form method="POST" enctype="multipart/form-data" action="<?php echo e($adminMode ? route('admin.event.update', $event) : ($event ? route('organizer.event.update', $event) : route('organizer.event.store'))); ?>" class="form-grid" data-submit-once>
                    <?php echo csrf_field(); ?>
                    <?php if($event): ?>
                        <?php echo method_field('PUT'); ?>
                    <?php endif; ?>

                    <div class="form-group full">
                        <label for="name">Nama event <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="name" class="input" name="name" value="<?php echo e(old('name', $event?->name)); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="category_id">Kategori <span class="required-mark" aria-hidden="true">*</span></label>
                        <select id="category_id" class="select" name="category_id" required>
                            <option value="">Pilih kategori</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $event?->category_id) == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="location">Lokasi atau platform <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="location" class="input" name="location" value="<?php echo e(old('location', $event?->location)); ?>" placeholder="Contoh: Auditorium, Jakarta atau Online" required>
                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group full">
                        <label for="description">Deskripsi event <span class="required-mark" aria-hidden="true">*</span></label>
                        <textarea id="description" name="description" rows="7" placeholder="Jelaskan topik, agenda singkat, dan siapa yang cocok mengikuti event ini." required><?php echo e(old('description', $event?->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="start_at">Mulai event <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="start_at" class="input" type="datetime-local" name="start_at" value="<?php echo e(old('start_at', $event?->start_at?->format('Y-m-d\TH:i'))); ?>" required>
                        <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="end_at">Selesai event <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="end_at" class="input" type="datetime-local" name="end_at" value="<?php echo e(old('end_at', $event?->end_at?->format('Y-m-d\TH:i'))); ?>" required>
                        <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="registration_start_at">Pendaftaran mulai <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="registration_start_at" class="input" type="datetime-local" name="registration_start_at" value="<?php echo e(old('registration_start_at', $event?->registration_start_at?->format('Y-m-d\TH:i'))); ?>" required>
                        <?php $__errorArgs = ['registration_start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="registration_end_at">Pendaftaran berakhir <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="registration_end_at" class="input" type="datetime-local" name="registration_end_at" value="<?php echo e(old('registration_end_at', $event?->registration_end_at?->format('Y-m-d\TH:i'))); ?>" required>
                        <?php $__errorArgs = ['registration_end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="poster">Poster event <span class="muted">(opsional)</span></label>
                        <input id="poster" class="input" type="file" name="poster" accept="image/jpeg,image/png,image/webp">
                        <small class="form-help">JPG, PNG, atau WebP maksimal 4 MB.</small>
                        <?php if($event?->poster_path): ?><small class="form-help">Poster saat ini tersimpan. Unggah file baru bila ingin menggantinya.</small><?php endif; ?>
                        <?php $__errorArgs = ['poster'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <?php ($ticket = $event?->ticketTypes?->first()); ?>
                    <div class="form-group">
                        <label for="ticket_name">Nama tiket gratis <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="ticket_name" class="input" name="ticket_name" value="<?php echo e(old('ticket_name', $ticket?->name ?? 'General Pass')); ?>" required>
                        <?php $__errorArgs = ['ticket_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="ticket_quota">Kuota tiket <span class="required-mark" aria-hidden="true">*</span></label>
                        <input id="ticket_quota" class="input" type="number" min="1" name="ticket_quota" value="<?php echo e(old('ticket_quota', $ticket?->quota ?? 100)); ?>" required>
                        <?php $__errorArgs = ['ticket_quota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group full"><div class="table-actions"><button class="btn btn-primary" type="submit"><?php echo e($adminMode ? 'Simpan perubahan' : 'Simpan draft event'); ?> <span aria-hidden="true">&rarr;</span></button><a class="btn btn-soft" href="<?php echo e(route($adminMode ? 'admin.event.show' : 'organizer.events', $adminMode ? $event : [])); ?>">Batal</a></div></div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($adminMode ? 'layouts.admin' : 'layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\organizer\event-form.blade.php ENDPATH**/ ?>