<?php $__env->startSection('content'); ?>
    <?php
        $organizerNavigation = [
            ['route' => 'organizer.dashboard', 'pattern' => 'organizer.dashboard', 'label' => 'Dashboard', 'icon' => '⌂'],
            ['route' => 'organizer.events', 'pattern' => 'organizer.events', 'label' => 'Event Saya', 'icon' => '◈'],
            ['route' => 'organizer.event.create', 'pattern' => 'organizer.event.create', 'label' => 'Buat Event', 'icon' => '+'],
            ['route' => 'organizer.registrations', 'pattern' => 'organizer.registrations', 'label' => 'Pendaftar', 'icon' => '◎'],
            ['route' => 'organizer.reports', 'pattern' => 'organizer.reports', 'label' => 'Laporan', 'icon' => '▤'],
        ];
        $currentOrganizerPage = collect($organizerNavigation)->first(fn ($item) => request()->routeIs($item['pattern']));
        $currentOrganizerPage = $currentOrganizerPage['label'] ?? 'Eventku';
        if (request()->routeIs('organizer.event.*') || request()->routeIs('organizer.checkin')) {
            $currentOrganizerPage = 'Event Saya';
        }
    ?>
    <div class="dashboard-shell organizer-dashboard-shell">
        <button class="sidebar-toggle" type="button" data-sidebar-toggle aria-expanded="false" aria-controls="organizer-sidebar">☰ <span>Menu organizer</span></button>
        <div class="sidebar-backdrop" data-sidebar-backdrop hidden></div>
        <aside class="sidebar organizer-sidebar" id="organizer-sidebar" aria-label="Navigasi organizer">
            <?php $__currentLoopData = $organizerNavigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($isActive = request()->routeIs($item['pattern']) || ($item['route'] === 'organizer.events' && (request()->routeIs('organizer.event.*') || request()->routeIs('organizer.checkin')))); ?>
                <a class="<?php echo e($isActive ? 'active' : ''); ?>" href="<?php echo e(route($item['route'])); ?>"><span class="sidebar-icon" aria-hidden="true"><?php echo e($item['icon']); ?></span><?php echo e($item['label']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </aside>
        <div class="dash-main">
            <nav class="breadcrumb workspace-breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo e(route('organizer.dashboard')); ?>">Dashboard</a>
                <?php if(! request()->routeIs('organizer.dashboard')): ?>
                    <span aria-hidden="true">/</span><span><?php echo e($currentOrganizerPage); ?></span>
                <?php endif; ?>
            </nav>
            <?php echo $__env->yieldContent('organizer-content'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/layouts/organizer.blade.php ENDPATH**/ ?>