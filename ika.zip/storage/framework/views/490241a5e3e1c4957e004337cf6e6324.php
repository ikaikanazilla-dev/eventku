<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['event', 'lazy' => true]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['event', 'lazy' => true]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<article class="event-card">
    <a class="event-card-media" href="<?php echo e(route('events.show', $event->slug)); ?>" aria-label="Lihat detail <?php echo e($event->name); ?>">
        <img src="<?php echo e($event->poster_url); ?>" alt="Poster <?php echo e($event->name); ?>" width="640" height="360" <?php if($lazy): ?> loading="lazy" <?php endif; ?> decoding="async">
        <span class="event-card-media-label"><?php echo e($event->category?->name ?? 'Event'); ?></span>
    </a>
    <div class="event-card-body">
        <div class="event-card-badges">
            <span class="badge"><?php echo e($event->category?->name ?? 'Event'); ?></span>
            <span class="badge badge-success">Gratis</span>
        </div>
        <h3><a href="<?php echo e(route('events.show', $event->slug)); ?>"><?php echo e($event->name); ?></a></h3>
        <div class="meta event-card-meta">
            <span title="<?php echo e($event->start_at->format('d M Y, H:i')); ?> WIB">
                <svg aria-hidden="true" viewBox="0 0 24 24"><path d="M7 3v3m10-3v3M4 9h16M6 5h12a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2Z"/></svg>
                <?php echo e($event->start_at->format('d M Y, H:i')); ?> WIB
            </span>
            <span title="<?php echo e($event->location); ?>">
                <svg aria-hidden="true" viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-12a7 7 0 1 0-14 0c0 5.8 7 12 7 12Z"/><circle cx="12" cy="9" r="2.2"/></svg>
                <?php echo e(Str::limit($event->location, 24)); ?>

            </span>
        </div>
        <p><?php echo e(Str::limit($event->description, 105)); ?></p>
        <div class="event-card-footer">
            <small><?php echo e($event->remainingQuota()); ?> tiket tersisa</small>
            <a class="btn btn-primary btn-sm" href="<?php echo e(route('events.show', $event->slug)); ?>">Lihat detail <span aria-hidden="true">&rarr;</span></a>
        </div>
    </div>
</article>
<?php /**PATH C:\xampp\htdocs\Eventku\resources\views/components/event-card.blade.php ENDPATH**/ ?>