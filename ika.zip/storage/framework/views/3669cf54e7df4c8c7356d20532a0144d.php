<?php $__env->startSection('admin-content'); ?>
    <section class="section">
        <div class="container">
            <div class="section-heading"><div><span class="eyebrow">KATALOG EVENT</span><h1>Kategori event</h1><p class="muted">Kelola kategori yang dipakai penyelenggara saat membuat event.</p></div></div>
            <div class="split">
                <div class="table-wrap"><table class="table"><thead><tr><th>Nama</th><th>Slug</th><th>Status</th></tr></thead><tbody><?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><strong><?php echo e($category->name); ?></strong></td><td><?php echo e($category->slug); ?></td><td><span class="badge badge-success">Aktif</span></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="empty">Belum ada kategori.</td></tr><?php endif; ?></tbody></table></div>
                <div class="card"><h2>Tambah kategori</h2><p class="muted">Gunakan nama yang singkat dan mudah dipahami peserta.</p><form method="POST" action="<?php echo e(route('admin.category.store')); ?>" data-submit-once style="display:flex;flex-direction:column;gap:15px;margin-top:20px"><?php echo csrf_field(); ?><div class="form-group"><label for="category-name">Nama kategori</label><input id="category-name" class="input" name="name" required></div><div class="form-group"><label for="category-description">Deskripsi <span class="muted">(opsional)</span></label><textarea id="category-description" name="description" rows="4"></textarea></div><button class="btn btn-primary" type="submit">Simpan kategori</button></form></div>
            </div>
            <div class="pagination"><?php echo e($categories->links()); ?></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\admin\categories.blade.php ENDPATH**/ ?>