<?php $__env->startSection('admin-content'); ?>
    <div class="dash-top">
        <div><span class="eyebrow">RUANG ADMIN</span><h1>Dashboard admin</h1><p class="muted">Pantau platform dan review event yang menunggu persetujuan.</p></div>
        <a class="btn btn-soft" href="<?php echo e(route('admin.events', ['status' => 'pending'])); ?>">Review tertunda (<?php echo e($stats['pending']); ?>)</a>
    </div>
    <div class="stat-grid">
        <div class="stat-card"><label>Total pengguna</label><strong><?php echo e($stats['users']); ?></strong><span class="muted"><?php echo e($stats['organizers']); ?> penyelenggara</span></div>
        <div class="stat-card"><label>Total peserta</label><strong><?php echo e($stats['participants']); ?></strong><span class="muted">Akun aktif</span></div>
        <div class="stat-card"><label>Total event</label><strong><?php echo e($stats['events']); ?></strong><span class="muted">Semua status</span></div>
        <div class="stat-card"><label>Check-in sukses</label><strong><?php echo e($stats['checkins']); ?></strong><span class="muted">Data kehadiran</span></div>
    </div>
    <div class="card">
        <div class="section-heading"><div><h2>Antrean review</h2><p class="muted">Event yang membutuhkan pemeriksaan admin.</p></div><a href="<?php echo e(route('admin.events')); ?>" class="btn btn-soft">Semua event</a></div>
        <div class="table-wrap"><table class="table"><thead><tr><th>Event</th><th>Penyelenggara</th><th>Jadwal</th><th>Aksi</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><strong><?php echo e($event->name); ?></strong><br><small><?php echo e($event->location); ?></small></td><td><?php echo e($event->organizer->name); ?></td><td><?php echo e($event->start_at->format('d M Y H:i')); ?> WIB</td><td><div class="table-actions"><a class="btn btn-soft btn-sm" href="<?php echo e(route('admin.event.edit', $event)); ?>">Edit</a><a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.event.show', $event)); ?>">Review</a></div></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="empty">Antrean kosong. Tidak ada event yang menunggu review.</td></tr>
            <?php endif; ?>
        </tbody></table></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>