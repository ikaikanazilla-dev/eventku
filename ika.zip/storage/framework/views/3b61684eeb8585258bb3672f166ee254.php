<?php $__env->startSection('content'); ?>
    <?php
        $registrationOpen = $event->isRegistrationOpen();
        $totalQuota = $event->ticketTypes->sum('quota');
        $remainingQuota = $event->remainingQuota();
    ?>

    <section class="detail-hero">
        <div class="container detail-grid">
            <div>
                <img class="detail-cover" src="<?php echo e($event->poster_url); ?>" alt="Poster <?php echo e($event->name); ?>" width="800" height="450">
            </div>
            <div class="detail-main">
                <span class="badge"><?php echo e($event->category?->name ?? 'Event'); ?> &middot; Gratis</span>
                <h1><?php echo e($event->name); ?></h1>
                <p>Diselenggarakan oleh <strong><?php echo e($event->organizer->name); ?></strong>. Temukan informasi jadwal, lokasi, dan cara mendaftar di halaman ini.</p>
                <div class="info-grid">
                    <div class="card"><small class="muted">Tanggal mulai</small><strong><?php echo e($event->start_at->format('d M Y')); ?></strong><small><?php echo e($event->start_at->format('H:i')); ?> WIB</small></div>
                    <div class="card"><small class="muted">Lokasi</small><strong title="<?php echo e($event->location); ?>"><?php echo e(Str::limit($event->location, 27)); ?></strong></div>
                    <div class="card"><small class="muted">Tiket tersisa</small><strong><?php echo e($remainingQuota); ?></strong><small>dari <?php echo e($totalQuota); ?> kuota</small></div>
                </div>
            </div>
        </div>
    </section>

    <section class="section">
        <div class="container detail-content">
            <div>
                <article class="card">
                    <span class="eyebrow">TENTANG EVENT</span>
                    <h2 style="margin-top:16px"><?php echo e($event->name); ?></h2>
                    <p class="detail-description"><?php echo e($event->description); ?></p>
                    <div class="detail-meta">
                        <span><strong>Waktu pendaftaran</strong> <?php echo e($event->registration_start_at->format('d M Y, H:i')); ?> &ndash; <?php echo e($event->registration_end_at->format('d M Y, H:i')); ?> WIB</span>
                        <span><strong>Lokasi atau platform</strong> <?php echo e($event->location); ?></span>
                        <span><strong>Penyelenggara</strong> <?php echo e($event->organizer->name); ?></span>
                    </div>
                </article>
            </div>

            <aside class="card booking-card">
                <span class="eyebrow">PILIH TIKET</span>
                <h2>Daftar untuk hadir</h2>
                <p class="muted">Tiket Eventku saat ini gratis. Kuota diperbarui berdasarkan pendaftaran aktif.</p>

                <?php if($registration): ?>
                    <div class="booking-message success">
                        Kamu sudah terdaftar di event ini. Tiket digitalmu siap digunakan.
                    </div>
                    <?php if($registration->digitalTicket): ?>
                        <a class="btn btn-primary" style="width:100%;margin-top:12px" href="<?php echo e(route('participant.ticket.show', $registration->digitalTicket)); ?>">Buka tiket digital</a>
                    <?php endif; ?>
                <?php else: ?>
                    <?php $__currentLoopData = $event->ticketTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ticket-option">
                            <div class="ticket-option-head"><strong><?php echo e($ticket->name); ?></strong><span class="badge badge-success">Gratis</span></div>
                            <p><?php echo e($ticket->description ?: 'Akses masuk ke event.'); ?></p>
                            <div class="ticket-option-foot"><small class="muted"><?php echo e($ticket->remainingQuota()); ?> tersisa</small>
                                <?php if(auth()->check() && auth()->user()->role === 'participant' && $registrationOpen && $ticket->remainingQuota() > 0): ?>
                                    <form method="POST" action="<?php echo e(route('participant.event.register', $event)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="ticket_type_id" value="<?php echo e($ticket->id); ?>">
                                        <button class="btn btn-primary btn-sm" type="submit">Daftar sekarang</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php if(!auth()->check()): ?>
                        <a class="btn btn-primary" style="width:100%;margin-top:14px" href="<?php echo e(route('login')); ?>">Masuk untuk mendaftar</a>
                    <?php elseif(auth()->user()->role !== 'participant'): ?>
                        <div class="booking-message">Akun <?php echo e(auth()->user()->role); ?> dapat mengelola event, tetapi pendaftaran peserta hanya tersedia untuk akun peserta.</div>
                    <?php elseif(!$registrationOpen): ?>
                        <div class="booking-message warning">Pendaftaran sedang ditutup. Periksa kembali jadwal pendaftaran event ini.</div>
                    <?php elseif($remainingQuota < 1): ?>
                        <div class="booking-message warning">Kuota event sudah penuh.</div>
                    <?php endif; ?>
                <?php endif; ?>
            </aside>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\public\event.blade.php ENDPATH**/ ?>