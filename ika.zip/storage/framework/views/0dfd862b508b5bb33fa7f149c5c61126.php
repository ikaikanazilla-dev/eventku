<?php $__env->startSection('organizer-content'); ?>
    <section class="section">
        <div class="container">
            <div class="section-heading"><div><span class="eyebrow">RUANG PENYELENGGARA</span><h1>Event Saya</h1><p class="muted">Kelola jadwal, tiket, dan status publikasi event milikmu.</p></div><a class="btn btn-primary" href="<?php echo e(route('organizer.event.create')); ?>">Buat event</a></div>
            <form class="filters organizer-filters" method="GET" action="<?php echo e(route('organizer.events')); ?>">
                <input class="input filter-search" type="search" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari nama atau lokasi event" aria-label="Cari event">
                <select class="select" name="status" aria-label="Filter status">
                    <option value="">Semua status</option>
                    <?php $__currentLoopData = ['draft' => 'Draft', 'pending' => 'Menunggu review', 'published' => 'Published', 'rejected' => 'Ditolak', 'cancelled' => 'Dibatalkan', 'completed' => 'Selesai']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button class="btn btn-primary" type="submit">Terapkan</button>
                <a class="btn btn-soft" href="<?php echo e(route('organizer.events')); ?>">Reset</a>
            </form>
            <div class="filter-summary"><span><strong><?php echo e($events->total()); ?></strong> event ditemukan</span></div>
            <div class="table-wrap"><table class="table"><thead><tr><th>Event</th><th>Jadwal</th><th>Tiket</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><strong><?php echo e($event->name); ?></strong><br><small><?php echo e($event->location); ?></small></td>
                        <td><?php echo e($event->start_at->format('d M Y H:i')); ?> WIB</td>
                        <td><?php echo e($event->ticketTypes->sum('quota')); ?></td>
                        <td><span class="badge <?php echo e($event->status === 'published' ? 'badge-success' : ($event->status === 'rejected' ? 'badge-danger' : 'badge-warning')); ?>"><?php echo e(ucfirst($event->status)); ?></span></td>
                        <td>
                            <div class="table-actions">
                                <a href="<?php echo e(route('organizer.event.show', $event)); ?>" class="btn btn-soft btn-sm">Detail</a>
                                <?php if(in_array($event->status, ['draft', 'rejected'], true)): ?>
                                    <a href="<?php echo e(route('organizer.event.edit', $event)); ?>" class="btn btn-soft btn-sm">Edit</a>
                                    <form method="POST" action="<?php echo e(route('organizer.event.destroy', $event)); ?>" onsubmit="return confirm('Hapus event ini? Data event yang sudah memiliki pendaftar tidak dapat dihapus.');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
                                    </form>
                                <?php endif; ?>
                                <?php if($event->status === 'published'): ?>
                                    <a href="<?php echo e(route('organizer.checkin', $event)); ?>" class="btn btn-soft btn-sm">Check-in</a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty">Belum ada event. Buat event pertamamu untuk memulai.</td></tr>
                <?php endif; ?>
            </tbody></table></div>
            <div class="pagination"><?php echo e($events->links()); ?></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.organizer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\organizer\events.blade.php ENDPATH**/ ?>