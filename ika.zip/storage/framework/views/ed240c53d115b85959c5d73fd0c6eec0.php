<?php $__env->startSection('content'); ?>
    <section class="page-head">
        <div class="container"><span class="eyebrow">KOLEKSI TIKET</span><h1>Tiket Saya</h1><p class="muted">Buka tiket digital dan QR check-in untuk event yang kamu ikuti.</p></div>
    </section>
    <section class="section">
        <div class="container">
            <?php if($registrations->count()): ?>
                <div class="event-grid">
                    <?php $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <article class="event-card">
                            <a class="event-card-media" href="<?php echo e(route('participant.ticket.show', $registration->digitalTicket)); ?>"><img src="<?php echo e($registration->event->poster_url); ?>" alt="Poster <?php echo e($registration->event->name); ?>" loading="lazy" width="640" height="360"></a>
                            <div class="event-card-body">
                                <span class="badge <?php echo e($registration->digitalTicket->status === 'valid' ? 'badge-success' : 'badge-neutral'); ?>"><?php echo e(ucfirst($registration->digitalTicket->status)); ?></span>
                                <h3><?php echo e($registration->event->name); ?></h3>
                                <p><?php echo e($registration->ticketType->name); ?> &middot; <?php echo e($registration->registration_code); ?></p>
                                <div class="meta"><span><?php echo e($registration->event->start_at->format('d M Y, H:i')); ?> WIB</span><span title="<?php echo e($registration->event->location); ?>"><?php echo e(Str::limit($registration->event->location, 22)); ?></span></div>
                                <div style="display:flex;gap:8px;margin-top:auto"><a class="btn btn-primary btn-sm" href="<?php echo e(route('participant.ticket.show', $registration->digitalTicket)); ?>">Detail</a><a class="btn btn-soft btn-sm" href="<?php echo e(route('participant.ticket.pdf', $registration->digitalTicket)); ?>" target="_blank" rel="noopener">Unduh PDF</a></div>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="pagination"><?php echo e($registrations->links()); ?></div>
            <?php else: ?>
                <div class="card empty"><h2>Belum ada tiket</h2><p class="muted">Tiket event yang kamu ikuti akan muncul di sini.</p><a class="btn btn-primary" href="<?php echo e(route('events.index')); ?>">Cari event</a></div>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views/participant/tickets.blade.php ENDPATH**/ ?>