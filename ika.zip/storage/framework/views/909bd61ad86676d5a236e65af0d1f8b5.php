<?php $__env->startSection('admin-content'); ?>
    <section class="section">
        <div class="container"><div class="section-heading"><div><span class="eyebrow">AKUN PLATFORM</span><h1>Pengguna</h1><p class="muted">Kelola peran dan status akun sesuai kebutuhan operasional.</p></div></div>
            <div class="table-wrap"><table class="table"><thead><tr><th>Pengguna</th><th>Email</th><th>Peran</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr><td><strong><?php echo e($user->name); ?></strong><br><small><?php echo e($user->phone ?: 'Nomor telepon belum diisi'); ?></small></td><td><?php echo e($user->email); ?></td><td><?php if(!$user->is(auth()->user())): ?><form method="POST" action="<?php echo e(route('admin.user.role', $user)); ?>" data-submit-once><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><label class="sr-only" for="role-<?php echo e($user->id); ?>">Peran <?php echo e($user->name); ?></label><select id="role-<?php echo e($user->id); ?>" class="select" name="role" style="min-width:130px;padding:8px" onchange="this.form.submit()"><option value="admin" <?php if($user->role === 'admin'): echo 'selected'; endif; ?>>Admin</option><option value="organizer" <?php if($user->role === 'organizer'): echo 'selected'; endif; ?>>Organizer</option><option value="participant" <?php if($user->role === 'participant'): echo 'selected'; endif; ?>>Peserta</option></select></form><?php else: ?><span class="badge"><?php echo e(ucfirst($user->role)); ?></span><?php endif; ?></td><td><span class="badge <?php echo e($user->status === 'active' ? 'badge-success' : 'badge-danger'); ?>"><?php echo e($user->status === 'active' ? 'Aktif' : 'Nonaktif'); ?></span></td><td><?php if(!$user->is(auth()->user())): ?><form method="POST" action="<?php echo e(route('admin.user.toggle', $user)); ?>" data-submit-once><?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?><button class="btn btn-soft btn-sm" type="submit"><?php echo e($user->status === 'active' ? 'Nonaktifkan' : 'Aktifkan'); ?></button></form><?php else: ?><small class="muted">Akun kamu</small><?php endif; ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty">Belum ada pengguna.</td></tr>
                <?php endif; ?>
            </tbody></table></div>
            <div class="pagination"><?php echo e($users->links()); ?></div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\admin\users.blade.php ENDPATH**/ ?>