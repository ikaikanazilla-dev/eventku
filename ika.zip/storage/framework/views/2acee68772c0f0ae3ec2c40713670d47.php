<?php $__env->startSection('content'); ?>
    <div class="auth-shell">
        <div class="auth-card">
            <span class="eyebrow">BUAT AKUN PESERTA</span>
            <h1>Mulai pengalaman event.</h1>
            <p>Buat akun untuk mendaftar event dan menyimpan tiket digitalmu.</p>
            <form method="POST" action="<?php echo e(route('register.store')); ?>" data-submit-once>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Nama lengkap</label>
                    <input id="name" class="input" name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" class="input" type="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="phone">Nomor telepon <span class="muted">(opsional)</span></label>
                    <input id="phone" class="input" name="phone" value="<?php echo e(old('phone')); ?>" autocomplete="tel">
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input id="password" class="input" type="password" name="password" autocomplete="new-password" minlength="8" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="password_confirmation">Konfirmasi password</label>
                    <input id="password_confirmation" class="input" type="password" name="password_confirmation" autocomplete="new-password" minlength="8" required>
                </div>
                <button class="btn btn-primary" type="submit">Buat akun peserta <span aria-hidden="true">&rarr;</span></button>
            </form>
            <p>Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk di sini</a></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Eventku\resources\views\auth\register.blade.php ENDPATH**/ ?>